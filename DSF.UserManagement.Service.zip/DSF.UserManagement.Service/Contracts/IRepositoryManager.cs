﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Contracts
{
    public interface IRepositoryManager: IDisposable
    {
        IOwnerRepository OwnerRepository { get; }
        //IAccountRepository AccountRepository { get; }
        void Commit();
        void RejectChanges();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}
