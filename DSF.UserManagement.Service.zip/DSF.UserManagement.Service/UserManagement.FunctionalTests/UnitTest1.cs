using System;
using Xunit;

namespace UserManagement.FunctionalTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
