import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-inheritance',
  templateUrl: './component-inheritance.component.html',
  styleUrls: ['./component-inheritance.component.css']
})
export class ComponentInheritanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
