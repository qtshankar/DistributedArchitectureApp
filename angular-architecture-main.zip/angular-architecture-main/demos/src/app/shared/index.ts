export { calcAge } from './age.pipe';
export { calcFullName } from './fullname.pipe';