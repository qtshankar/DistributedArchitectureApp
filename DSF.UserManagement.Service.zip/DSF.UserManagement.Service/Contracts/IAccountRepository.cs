﻿using Domain;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Contracts
{
    //public interface IAccountRepository : IRepositoryBase<Account>
    //{
    //    Task<IEnumerable<Account>> GetAllAccountsAsync();
    //    Task<Account> GetAccountByIdAsync(Guid accountId, CancellationToken cancellationToken = default);
    //    Task<Account> GetAccountWithDetailsAsync(Guid accountId);
    //    void CreateAccount(Account account);
    //    void UpdateAccount(Account account);
    //    void DeleteAccount(Account account);
    //}


}
