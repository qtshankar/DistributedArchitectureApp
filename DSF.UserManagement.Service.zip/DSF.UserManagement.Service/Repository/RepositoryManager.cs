﻿using Contracts;
using Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Repository
{
    public class RepositoryManager : IRepositoryManager
    {
        private RepositoryDbContext _repoContext;
        private IOwnerRepository _owner;
        //private IAccountRepository _account;
        public IOwnerRepository OwnerRepository
        {
            get
            {
                if (_owner == null)
                {
                    _owner = new OwnerRepository(_repoContext);
                }
                return _owner;
            }
        }

        //public IAccountRepository AccountRepository
        //{
        //    get
        //    {
        //        if (_account == null)
        //        {
        //            _account = new AccountRepository(_repoContext);
        //        }
        //        return _account;
        //    }
        //}

        public RepositoryManager(RepositoryDbContext repositoryContext)
        {
            _repoContext = repositoryContext;
        }

       

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repoContext.Dispose();
            }
        }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return await _repoContext.SaveChangesAsync(cancellationToken);
        }

        public void Commit()
        {
            _repoContext.SaveChanges();
        }

        public void RejectChanges()
        {
            foreach (var entry in _repoContext.ChangeTracker.Entries()
                  .Where(e => e.State != EntityState.Unchanged))
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.State = EntityState.Detached;
                        break;
                    case EntityState.Modified:
                    case EntityState.Deleted:
                        entry.Reload();
                        break;
                }
            }
        }
    }
}
