﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.DataTransferObjects
{
    public class AccountForCreationDto
    {
        [Required(ErrorMessage = "Id is required")]
        [StringLength(60, ErrorMessage = "Id can't be longer than 60 characters")]
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Date Created is required")]
        public DateTime DateCreated { get; set; }

        [Required(ErrorMessage = "Account Type is required")]
        [StringLength(100, ErrorMessage = "Account Type cannot be loner then 100 characters")]
        public string AccountType { get; set; }
    }
}
