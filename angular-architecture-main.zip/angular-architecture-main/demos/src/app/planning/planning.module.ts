import { NgModule } from '@angular/core';

import { PlanningRoutingModule } from './planning-routing.module';

@NgModule({
    imports: [ PlanningRoutingModule ],
    declarations: [ PlanningRoutingModule.components ],
})
export class PlanningModule { }