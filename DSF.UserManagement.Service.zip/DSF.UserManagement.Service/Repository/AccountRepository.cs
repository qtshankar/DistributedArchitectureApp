﻿using Contracts;
using Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repository
{
    //public class AccountRepository : RepositoryBase<Account>, IAccountRepository
    //{
    //    public AccountRepository(RepositoryDbContext repositoryDbContext)
    //        : base(repositoryDbContext)
    //    {
    //    }

    //    public IEnumerable<Account> AccountsByOwner(Guid ownerId)
    //    {
    //        return FindByCondition(a => a.OwnerId.Equals(ownerId)).ToList();
    //    }

    //    public async Task<Account> GetAccountByIdAsync(Guid accountId)
    //    {
    //        return await FindByCondition(owner => owner.Id.Equals(accountId))
    //            .FirstOrDefaultAsync();
    //    }

    //    public async Task<Account> GetAccountWithDetailsAsync(Guid accountId)
    //    {
    //        return await FindByCondition(owner => owner.Id.Equals(accountId))
    //            .FirstOrDefaultAsync();
    //    }

    //    public async Task<IEnumerable<Account>> GetAllAccountsAsync()
    //    {
    //        return await FindAll()
    //           .OrderBy(ow => ow.OwnerId)
    //           .ToListAsync();
    //    }

    //    public void CreateAccount(Account account)
    //    {
    //        Create(account);
    //    }

    //    public void UpdateAccount(Account account)
    //    {
    //        Update(account);
    //    }

    //    public void DeleteAccount(Account account)
    //    {
    //        Delete(account);
    //    }


    //}
}
