﻿using Contracts;
using Domain;
using Domain.DataTransferObjects;
using Domain.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Services
{
    internal sealed class OwnerService : IOwnerService
    {
        private readonly IRepositoryManager _repositoryManager;

        public OwnerService(IRepositoryManager repositoryManager) => _repositoryManager = repositoryManager;

        //public async Task<IEnumerable<OwnerDto>> GetAllAsync(CancellationToken cancellationToken = default)
        //{
        //    var owners = await _repositoryManager.OwnerRepository.GetAllOwnersAsync(cancellationToken);

        //    var ownersDto = owners.Adapt<IEnumerable<OwnerDto>>();

        //    return ownersDto;
        //}

        //public async Task<OwnerDto> GetByIdAsync(Guid ownerId, CancellationToken cancellationToken = default)
        //{
        //    var owner = await _repositoryManager.OwnerRepository.GetOwnerByIdAsync(ownerId, cancellationToken);

        //    if (owner is null)
        //    {
        //        throw new OwnerNotFoundException(ownerId);
        //    }

        //    var ownerDto = owner.Adapt<OwnerDto>();

        //    return ownerDto;
        //}

        public async Task<IEnumerable<Owner>> GetAllAsync(CancellationToken cancellationToken = default)
        {
            return await _repositoryManager.OwnerRepository.GetAllOwnersAsync(cancellationToken);
        }

        public async Task<Owner> GetByIdAsync(Guid ownerId, CancellationToken cancellationToken = default)
        {
            return await _repositoryManager.OwnerRepository.GetOwnerByIdAsync(ownerId, cancellationToken);
        }

        //public async Task<OwnerDto> CreateAsync(OwnerForCreationDto ownerForCreationDto, CancellationToken cancellationToken = default)
        //{
        //    var owner = ownerForCreationDto.Adapt<Owner>();

        //    _repositoryManager.OwnerRepository.Create(owner);

        //    await _repositoryManager.SaveChangesAsync(cancellationToken);

        //    return owner.Adapt<OwnerDto>();
        //}

        //public async Task UpdateAsync(Guid ownerId, OwnerForUpdateDto ownerForUpdateDto, CancellationToken cancellationToken = default)
        //{
        //    var owner = await _repositoryManager.OwnerRepository.GetOwnerByIdAsync(ownerId, cancellationToken);

        //    if (owner is null)
        //    {
        //        throw new OwnerNotFoundException(ownerId);
        //    }

        //    owner.Name = ownerForUpdateDto.Name;
        //    owner.DateOfBirth = ownerForUpdateDto.DateOfBirth;
        //    owner.Address = ownerForUpdateDto.Address;

        //    await _repositoryManager.SaveChangesAsync(cancellationToken);
        //}

        //public async Task DeleteAsync(Guid ownerId, CancellationToken cancellationToken = default)
        //{
        //    var owner = await _repositoryManager.OwnerRepository.GetOwnerByIdAsync(ownerId, cancellationToken);

        //    if (owner is null)
        //    {
        //        throw new OwnerNotFoundException(ownerId);
        //    }

        //    _repositoryManager.OwnerRepository.DeleteOwner(owner);

        //    await _repositoryManager.SaveChangesAsync(cancellationToken);
        //}

    }
}
