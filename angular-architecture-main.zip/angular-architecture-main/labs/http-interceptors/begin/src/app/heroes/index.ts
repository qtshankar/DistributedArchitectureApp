import { HeroesComponent } from "./heroes.component";
import { HeroListComponent } from "./hero-list.component";

export const heroComponents = [HeroesComponent, HeroListComponent];
