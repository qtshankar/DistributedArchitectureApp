using System;
using Xunit;

namespace UserManagement.UnitTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
